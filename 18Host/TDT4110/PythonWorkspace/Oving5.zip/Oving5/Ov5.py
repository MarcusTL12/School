import Oving5.Undersokelse as und
import Oving5.Arbdag as arb
import Oving5.Sek as sek
import Oving5.Blackjack as bj


def run():
	# und.run()

	# arb.a()
	# arb.b()
	# arb.c()
	
	# sek.a()
	# sek.b()
	# sek.c()

	bj.run()
	return
