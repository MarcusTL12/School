import Oving1.AbsKunst as ak
import Oving1.SciNot as sn
import Oving1.Tetra as tet
import Oving1.Bake as bake
import Oving1.OpRound as opr

def run():
    input("\nPress enter to proceed to AbsKunst a)\n")
    ak.a()
    input("\nPress enter to proceed to AbsKunst b)\n")
    ak.b()

    input("\nPress enter to proceed to SciNot a)\n")
    sn.a()
    input("\nPress enter to proceed to SciNot b)\n")
    sn.b()

    input("\nPress enter to proceed to Tetra abc)\n")
    tet.abc()

    input("\nPress enter to proceed to bake ab)\n")
    bake.ab()

    input("\nPress enter to proceed to OpRound a)\n")
    opr.a()
    input("\nPress enter to proceed to OpRound b)\n")
    opr.b()
    input("\nPress enter to proceed to OpRound c)\n")
    opr.c()
