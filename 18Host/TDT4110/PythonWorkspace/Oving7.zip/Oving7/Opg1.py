

def printstring(s):
	for i in s:
		print(i)


def printthird(s):
	if len(s) >= 3:
		print(s[2])


def largestindex(s):
	return len(s) - 1


def a():
	s = input()
	printstring(s)


