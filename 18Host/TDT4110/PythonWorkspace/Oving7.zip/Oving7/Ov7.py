import Oving7.Sorting as sort
import Oving7.StringMan as strman
import Oving7.Krypto as kr
import Oving7.Opg1 as op1


def run():
	# sort.a()

	# strman.a()
	# strman.b()
	
	# kr.b()
	# kr.c()

	op1.a()
	pass
