import Oving3.Fibb as fibb
import Oving3.AltSum as alt
import Oving3.Hangman as hang
import Oving3.Dobbloop as dl


def run():
    # fibb.a()
    # fibb.b()
    # fibb.c()

    # alt.a()
    # alt.b()

    # hang.run()

    # dl.a()
    # dl.b()
    # dl.c()
    # dl.d()
    return
