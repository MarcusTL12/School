import Oving2.Chess as chess
import Oving2.Bilett as bilett
import Oving2.Trekant as trekant
import Oving2.Andregradsformel as abc


def run():
    # chess.ab()

    # bilett.c()

    # trekant.a()
    # trekant.b()

    abc.run()
    return
